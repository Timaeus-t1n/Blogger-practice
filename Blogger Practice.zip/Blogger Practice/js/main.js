const mainMenu = document.querySelector('.nav-menu')
const openMenu = document.querySelector('.toggle-collapse')
const closeMenu = document.querySelector('.close-icons')
const Title = document.querySelector('.nav-brand')
const content = document.querySelector('.nav-items')

openMenu.addEventListener('click' ,show)
closeMenu.addEventListener('click' ,close)

function show(){
    mainMenu.style.display = 'flex';
    mainMenu.style.top = '10';
    closeMenu.style.display = 'block';
    content.style.display = 'intial';
}

function close(){
   mainMenu.style.top ='-10';
}

